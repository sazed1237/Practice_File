                <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <meta http-equiv="X-UA-Compatible" content="IE=edge">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>bangladesh.gov.bd </title>
                    <!-- <link rel="stylesheet" href="./style.css"> -->
                    <!-- <link rel="stylesheet" href="./assest/css/bootstrap.min.css"> -->
                    <?php wp_head(); ?>

                </head>
                <body>
                    <!-- topbar start -->
                    <section class="cont top_bar">
                        <div class="row">
                            <div class="col-sm-6">
                                <?php dynamic_sidebar('topheadleft') ?>
                        </div>
                            <div class="col-sm-5 text-end">
                            <?php dynamic_sidebar('topheadmidle') ?>
                            </div>
                            <div class="col-sm-1  text_topbar">
                            <?php dynamic_sidebar('topheadright') ?>
                        </div>
                        </div>
                    </section>
                <!-- topbar end -->
                <!-- logo part start -->
                <section class="cont logo">
                    <div class="row">
                        <div class="col-sm-6 logo_left">
                        <?php dynamic_sidebar('mainlogo') ?>
                            <!-- <a href="#"><img src="./assest/image/header/logo_bn.png" alt=""></a> -->
                        </div>
                        <div class="col-sm-4 search_box">
                        <?php dynamic_sidebar('search') ?>
                            <!-- <div class="input-group">
                                <input type="search" class="form-control rounded" placeholder="Search" aria-label="Search" aria-describedby="search-addon" />
                                <button type="button" class="btn btn-outline-primary">search</button>
                            </div> -->
                        </div>

                        <div class="col-sm-2 d-flex logo_right ">
                            <div class="logo_1" >
                        <?php dynamic_sidebar('a2i') ?>
                                <!-- <a href="#"><img src="./assest/image/header/a2i-logo-footer.png" alt=""></a> -->
                            </div>

                            <div class=" logo_4 d-block">
                            <p>Stay Connected:</p>
                            <div class="logo_4_img d-flex">
                            <?php dynamic_sidebar('socialinks') ?>
                                <!-- <a href="#"><img src="./assest/image/header/facebook-icon.png" alt=""></a>
                                <a href="#"><img src="./assest/image/header/gplus-icon.png" alt=""></a>
                                <a href="#"><img src="./assest/image/header/twitter-blue-icon.png" alt=""></a>
                                <a href="#"><img src="./assest/image/header/youtube-icon.png" alt=""></a> -->
                            </div> 
                            </div>
                        </div>
                    </div>
                </section>
                <!-- logo part end -->



                <!-- menu part start  -->
                <section class="cont menu d-flex">
                <nav class="navbar navbar-expand-lg bg-body-tertiary">
                    <div class="container-fluid">
                       
                        <div class="collapse navbar-collapse" id="navbarNav">
                            <?php
                                wp_nav_menu([
                                    'menu_locations'=>'TM',
                                    'class_menu'=>'navbar menu'
                                ]);
                            ?>
                        <ul class="navbar-nav">
                            <li class="nav-item">
                            <!-- <a class="nav-link active" aria-current="page" href="#">Home</a> -->
                            </li>
                        
                        </ul>
                        </div>
                    </div>
                    </nav>
                    </section>
                <!-- menu part end  -->
                <!-- hero part start -->
                <section class="cont hero_part">
                    <?php 
                        $xyz = new WP_Query([
                            'post_type'=>'post',
                            'category_name'=>'slider'
                        ]);                    
                    ?>
                    <div class="row">
                    <div class="col-sm-8">
                        <div class="banner">
                            <?php dynamic_sidebar('banner') ?>
                            <!-- <a href="#">  <img src="./assest/image/padmabanner.jpg" alt=""></a> -->
                        </div>
                        <div class="slider">
                            <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="true">
                                <div class="carousel-indicators">
                                    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                                    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
                                    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
                                </div>
                                <div class="carousel-inner">

                                <?php 
                                    $x=0;
                                    while ($xyz->have_posts()):$xyz->the_post();
                                    $x++;
                                ?>
                                    <div class="carousel-item<?= ($x==1)? 'active': ''?> ">
                                        <?php the_post_thumbnail(); ?>

                                    <!-- <img src="./assest/image/slider/333_gov.png" class="d-block w-100" alt="..."> -->
                                    </div>
                                    <!-- <div class="carousel-item">
                                    <img src="./assest/image/slider/4-02.jpg" class="d-block w-100" alt="...">
                                    </div>
                                    <div class="carousel-item">
                                    <img src="./assest/image/slider/myGov Static2(1) (1).jpg" class="d-block w-100" alt="...">
                                    </div> -->
                                    <?php endwhile ?>
                                </div>
                                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">Previous</span>
                                </button>
                                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">Next</span>
                                </button>
                                </div>
                        </div>
                        <div class="tab">
                            <nav>
                                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                    <button class="nav-link active" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home" aria-selected="true">popular service</button>
                                    <button class="nav-link" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile" aria-selected="false">new service</button>
                                    <button class="nav-link" id="nav-contact-tab" data-bs-toggle="tab" data-bs-target="#nav-contact" type="button" role="tab" aria-controls="nav-contact" aria-selected="false">mobile service</button>
                                    <button class="nav-link" id="nav-disabled-tab" data-bs-toggle="tab" data-bs-target="#nav-disabled" type="button" role="tab" aria-controls="nav-disabled" aria-selected="false" >office service</button>
                                </div>
                                </nav>
                                <div class="tab-content" id="nav-tabContent">
                                <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab" tabindex="0">
                                    <div class="row">
                                        <div class="col-sm-2">
                                                <?php dynamic_sidebar('tab1') ?>
                                            <!-- <img src="./assest/image/tab/agriculture.png" alt="">
                                            <p>agriculture</p> -->
                                        </div>
                                        <div class="col-sm-2">
                                        <?php dynamic_sidebar('tab1') ?>

                                            <!-- <img src="./assest/image/tab/agriculture.png" alt="">
                                            <p>agriculture</p> -->
                                        </div>
                                        <div class="col-sm-2">
                                        <?php dynamic_sidebar('tab1') ?>

                                            <!-- <img src="./assest/image/tab/agriculture.png" alt="">
                                            <p>agriculture</p> -->
                                        </div>
                                        <div class="col-sm-2">
                                            <img src="./assest/image/tab/agriculture.png" alt="">
                                            <p>agriculture</p>
                                        </div>
                                        <div class="col-sm-2">
                                            <img src="./assest/image/tab/agriculture.png" alt="">
                                            <p>agriculture</p>
                                        </div>
                                        <div class="col-sm-2">
                                            <img src="./assest/image/tab/agriculture.png" alt="">
                                            <p>agriculture</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab" tabindex="0">...</div>
                                <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab" tabindex="0">
                                    <div class="row">
                                    <?php 
                                        $xyz2 = new WP_Query([
                                            'post_type'=>'post',
                                            'category_name'=>'tab'
                                        ]);                    
                                    ?>
                                        
                                        <div class="col-sm-2 tab">

                                        <?php
                                            while ($xyz2->have_posts()):$xyz2->the_post();
                                        ?>
                                        <div class="tab1 d-block">
                                            <?php the_post_thumbnail(); ?>
                                            <?php the_title(); ?>
                                            <!-- <img src="./assest/image/tab/agriculture.png" alt="">
                                            <p>agriculture</p> -->
                                        </div>
                                           
                                        <?php endwhile; ?>

                                        </div>
                                        <div class="col-sm-2">
                                            <img src="./assest/image/tab/agriculture.png" alt="">
                                            <p>agriculture</p>
                                        </div>
                                        <div class="col-sm-2">
                                            <img src="./assest/image/tab/agriculture.png" alt="">
                                            <p>agriculture</p>
                                        </div>
                                        <div class="col-sm-2">
                                            <img src="./assest/image/tab/agriculture.png" alt="">
                                            <p>agriculture</p>
                                        </div>
                                        <div class="col-sm-2">
                                            <img src="./assest/image/tab/agriculture.png" alt="">
                                            <p>agriculture</p>
                                        </div>
                                        <!-- <div class="col-sm-2">
                                            <img src="./assest/image/tab/agriculture.png" alt="">
                                            <p>agriculture</p>
                                        </div> -->
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="nav-disabled" role="tabpanel" aria-labelledby="nav-disabled-tab" tabindex="0">...</div>
                                </div>
                        </div>
                        
                        <div class="news"> 
                            <div>
                            <h5>news</h5>
                            
                            <a href="#"> THE SEVENTH FIVE YEAR PLAN (2016-2020) (13-06-2016) </a><br>
                            <a href="#"> THE SEVENTH FIVE YEAR PLAN (2016-2020) (13-06-2016) </a><br>
                            <a href="#"> THE SEVENTH FIVE YEAR PLAN (2016-2020) (13-06-2016) </a><br>
                            <a href="#"> THE SEVENTH FIVE YEAR PLAN (2016-2020) (13-06-2016) </a><br>
                            <a href="#"> THE SEVENTH FIVE YEAR PLAN (2016-2020) (13-06-2016) </a><br>
                            <a href="#"> THE SEVENTH FIVE YEAR PLAN (2016-2020) (13-06-2016) </a><br>
                            <a href="#"> THE SEVENTH FIVE YEAR PLAN (2016-2020) (13-06-2016) </a><br>
                            <button>
                                all
                            </button>
                            </div>  
                            </div>
                        
                            
                            <div class="hero_pic d-flex">
                                <div>
                                    <a href="#"><img src="./assest/hero pic/forms_portal_logo (1).png" alt=""></a>
                                    <a href="#"><img src="./assest/hero pic/forms_portal_logo (1).png" alt=""></a>
                                    <a href="#"><img src="./assest/hero pic/forms_portal_logo (1).png" alt=""></a><br>
                                    <a href="#"><img src="./assest/hero pic/forms_portal_logo (1).png" alt=""></a>
                                    <a href="#"><img src="./assest/hero pic/forms_portal_logo (1).png" alt=""></a>
                                    <a href="#"><img src="./assest/hero pic/forms_portal_logo (1).png" alt=""></a>
                                </div>
                                </div>
                        
                                <div class="youtube1">
                                    <p>আশ্রয়ণের অধিকার শেখ হাসিনার উপহার
                                    </p>
                                    <?php dynamic_sidebar('bvideo') ?>
                                    <!-- <iframe width="218" height="150" src="https://www.youtube.com/embed/l7G3TPz6P24" title="আশ্রয়ণের অধিকার শেখ হাসিনার উপহার" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                                    <iframe width="218" height="150" src="https://www.youtube.com/embed/l7G3TPz6P24" title="আশ্রয়ণের অধিকার শেখ হাসিনার উপহার" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                                    <iframe width="218" height="150" src="https://www.youtube.com/embed/l7G3TPz6P24" title="আশ্রয়ণের অধিকার শেখ হাসিনার উপহার" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe><br>
                                    <p>other video</p>
                                    <iframe width="218" height="150" src="https://www.youtube.com/embed/l7G3TPz6P24" title="আশ্রয়ণের অধিকার শেখ হাসিনার উপহার" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                                    <iframe width="218" height="150" src="https://www.youtube.com/embed/l7G3TPz6P24" title="আশ্রয়ণের অধিকার শেখ হাসিনার উপহার" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                                    <iframe width="218" height="150" src="https://www.youtube.com/embed/l7G3TPz6P24" title="আশ্রয়ণের অধিকার শেখ হাসিনার উপহার" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> -->
                                </div>
                    </div>
                    <div class="col-sm-4">
                        <row class="sidebar">
                            <?php dynamic_sidebar($index) ?>
                            <!-- <a href="#"><img src="./assest/image/sidebar/Bangladesh-Directory.jpg" alt=""></a>
                            <a href="#"><img src="./assest/image/sidebar/Bangladesh-Directory.jpg" alt=""></a>
                            <a href="#"><img src="./assest/image/sidebar/Bangladesh-Directory.jpg" alt=""></a>
                            <a href="#"><img src="./assest/image/sidebar/Bangladesh-Directory.jpg" alt=""></a>
                            <a href="#"><img src="./assest/image/sidebar/Bangladesh-Directory.jpg" alt=""></a>
                            <a href="#"><img src="./assest/image/sidebar/Bangladesh-Directory.jpg" alt=""></a>
                            <a href="#"><img src="./assest/image/sidebar/Bangladesh-Directory.jpg" alt=""></a>
                            <a href="#"><img src="./assest/image/sidebar/Bangladesh-Directory.jpg" alt=""></a>
                            <a href="#"><img src="./assest/image/sidebar/Bangladesh-Directory.jpg" alt=""></a>
                            <a href="#"><img src="./assest/image/sidebar/Bangladesh-Directory.jpg" alt=""></a>
                            <a href="#"><img src="./assest/image/sidebar/Bangladesh-Directory.jpg" alt=""></a> -->
                        </row>
                        <row class="searchbox">
                            <p>সকল বাতায়ন</p>
                            <div class="dropdown show">
                                <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                  Dropdown link
                                </a>
                              
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                  <a class="dropdown-item" href="#">Action</a>
                                  <a class="dropdown-item" href="#">Another action</a>
                                  <a class="dropdown-item" href="#">Something else here</a>
                                </div>
                              </div>
                              <iframe width="315" height="200" src="https://www.youtube.com/embed/4Om3kZJL-qU" title="MUJIB100 APP | Speeches, Quotes, Books &amp; More | Get Inspired Everyday" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                       <p>মাস্ক পরুন সেবা নিন
                    </p>
                    <img src="./assest/image/sidebar/mask-bd-portal (1).jpg" alt="">
                            </row>
                    </div>
                    </div>
                <!-- hero part end -->
                <!-- footer part -->
                <footer>
                    <div class="footer_img">
                        <img src="./assest/image/footer/footer_top_bg.png" alt="">
                    </div>
                
            </section>
            <section class="cont menu_footer">
                <div class="row">
                    <nav class="navbar navbar-expand-lg ">
                        <div class="container-fluid">
                        <div class="collapse navbar-collapse" id="navbarNav">
                            <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="#">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="#">About Bangladesh</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="#">e-Services</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="#">Service Sectors</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="#">Trade & Business</a>
                            </li>
                            <li class=" menu_footer_p ">
                                <p>পরিকল্পনা ও বাস্তবায়নে: এটুআই, মন্ত্রিপরিষদ বিভাগ, বিসিসি, বেসিস, ডিওআইসিটি</p>
                            </li>
                            </ul>
                        </div>
                        </div>
                    </nav>
                </div>
            </section>
            <section class="cont footer_end ">
                <div class="row">
                    <div class="col-sm-6">
                        <p>সাইটটি শেষ হাল-নাগাদ করা হয়েছে: ২০২৩-০২-০৫ ০৬:১৯:৫২</p>
                    </div>
                    <div class="col-sm-6 text-end">
                        <img src="./assest/image/footer/np-logo-set.png" alt="">
                    </div>
                </div>
            </section>
        </footer>


                    <?php wp_footer(); ?>
                    <!-- <script src="./assest/js/bootstrap.bundle.min.js"></script> -->
                </body>
                </html>