<?php 

    wp_enqueue_style( 'style-name', get_stylesheet_uri() );
    wp_enqueue_style( 'style-bootstrap', get_template_directory_uri() . '/assest/css/bootstrap.min.css', array() );
	wp_enqueue_script( 'script-name', get_template_directory_uri() . '/assest/js/bootstrap.bundle.min.js', array(), '1.0.0', true );


    add_theme_support( 'title-tag' );
    add_theme_support( 'custom-logo');
    add_theme_support( 'post-thumbnails' );


    register_sidebar([
        'name'=>'top head left',
        'id'=>'topheadleft',
        'before_widget'=>'',
        'after_widget'=>''
    ]);

    register_sidebar([
        'name'=>'top head midle',
        'id'=>'topheadmidle',
        'before_widget'=>'',
        'after_widget'=>''
    ]);
    register_sidebar([
        'name'=>'top head right',
        'id'=>'topheadright',
        'before_widget'=>'',
        'after_widget'=>''
    ]);
    register_sidebar([
        'name'=>'Main logo',
        'id'=>'mainlogo',
        'before_widget'=>'',
        'after_widget'=>''
    ]);
    register_sidebar([
        'name'=>'search',
        'id'=>'search',
        'before_widget'=>'',
        'after_widget'=>''
    ]);
    register_sidebar([
        'name'=>'a2i',
        'id'=>'a2i',
        'before_widget'=>'',
        'after_widget'=>''
    ]);
    register_sidebar([
        'name'=>'social links',
        'id'=>'socialinks',
        'before_widget'=>'',
        'after_widget'=>''
    ]);

    register_nav_menus([
        'TM'=>'Primary Menu',
        'FT'=>"Footer Menu"
    ]);

    register_sidebar([
        'name'=>'banner',
        'id'=>'banner',
        'before_widget'=>'',
        'after_widget'=>''
    ]);
    register_sidebar([
        'name'=>'tab1',
        'id'=>'tab1',
        'before_widget'=>'',
        'after_widget'=>''
    ]);
    register_sidebar([
        'name'=>'body video',
        'id'=>'bvideo',
        'before_widget'=>'',
        'after_widget'=>''
    ]);
?>