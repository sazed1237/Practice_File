
<?php get_header(); ?>


<?php 
    while(have_posts()):the_post();
?>

<div class="container">
    <div class="row">
            <div class="bg-danger text-center">
                <?php the_title('<h1>','</h1>'); ?>
            </div>
            <div class="hero">
                <?php the_content();?>
            </div>

    </div>
</div>

<?php endwhile; ?>

<?php get_footer(); ?>