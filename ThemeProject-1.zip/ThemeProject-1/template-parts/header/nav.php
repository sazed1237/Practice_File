<section class="header">
            <div class="row">
                <div class="col-sm-6 head_left">
                <?php the_custom_logo(); ?>
            </div>
                <div class="col-sm-6 head_right">
                    <div class="menu">
               <nav class="navbar navbar-expand-lg bg-body-tertiary">
                        <div class="container-fluid">
                            
                            <div class="collapse navbar-collapse" id="navbarNav">
                            <?php
                                wp_nav_menu([
                                    'menu_locations'=> 'Tm',
                                    'menu_class'=>'navbar'
                                ]);

                            ?>

                            <ul class="navbar-nav">
                                <li class="nav-item">
                                <!-- <a class="nav-link active" aria-current="page" href="#">Home</a> -->
                                </li>
                            
                            </ul>
                            </div>
                        </div>
                        </nav>
                    </div>
                    </div>`
            </div>
        </section>