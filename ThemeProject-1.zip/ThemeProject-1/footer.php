<footer>
            <div class="container">
                <div class="row">
                    <div class="sm-lg-6 footer_left">
                        <?php dynamic_sidebar('f_left'); ?>
                    </div>
                    <div class="sm-lg-6 footer_right">
                    <?php dynamic_sidebar('f_right'); ?>

                    </div>
                </div>
            </div>
        </footer>

    <?php wp_footer(); ?>
</body>
</html>