<?php

wp_enqueue_style( 'style-name', get_stylesheet_uri() );

wp_enqueue_style( 'style-bootstrap', get_template_directory_uri().'/assets/css/bootstrap.min.css' );


wp_enqueue_script( 'script', get_template_directory_uri().'/assets/js/bootstrap.bundle.min.js', array(), 1.0, 'true' );


add_theme_support( 'title-tag' );
add_theme_support( 'custom-logo');
add_theme_support('post-thumbnails');

register_nav_menus([
    'TM_1'=>'Primary',
    'FM'=>'Footer'
]);

// register_nav_menus_1([
//     'TM_1'=>'Primary',
//     'FM'=>'Footer'
// ]);


register_sidebar([
    'name'=>'Main Banner',
    'id'=>'mainbanner',
    'before_widget'=>'',
    'after_widget'=>''
]);

register_sidebar([
    'name'=>'Side Image',
    'id'=>'sideimg',
    'before_widget'=>'',
    'after_widget'=>''
]);

register_sidebar([
    'name'=>'Side video',
    'id'=>'sidevideo',
    'before_widget'=>'',
    'after_widget'=>''
]);

register_sidebar([
    'name'=>'Side Image_dengue',
    'id'=>'sideimg_dengue',
    'before_widget'=>'',
    'after_widget'=>''
]);

register_sidebar([
    'name'=>'Side Image_mask',
    'id'=>'sideimg_mask',
    'before_widget'=>'',
    'after_widget'=>''
]);

register_sidebar([
    'name'=>'Side video_1',
    'id'=>'sidevideo_1',
    'before_widget'=>'',
    'after_widget'=>''
]);

register_sidebar([
    'name'=>'Side video_2',
    'id'=>'sidevideo_2',
    'before_widget'=>'',
    'after_widget'=>''
]);

register_sidebar([
    'name'=>'Side Image_1',
    'id'=>'sideimg_1',
    'before_widget'=>'',
    'after_widget'=>''
]);

register_sidebar([
    'name'=>'Notice_1',
    'id'=>'noticetext_1',
    'before_widget'=>'',
    'after_widget'=>''
]);

register_sidebar([
    'name'=>'Notice_2',
    'id'=>'noticetext_2',
    'before_widget'=>'',
    'after_widget'=>''
]);
register_sidebar([
    'name'=>'Notice_3',
    'id'=>'noticetext_3',
    'before_widget'=>'',
    'after_widget'=>''
]);
register_sidebar([
    'name'=>'Notice_4',
    'id'=>'noticetext_4',
    'before_widget'=>'',
    'after_widget'=>''
]);
register_sidebar([
    'name'=>'Notice_5',
    'id'=>'noticetext_5',
    'before_widget'=>'',
    'after_widget'=>''
]);

register_sidebar([
    'name'=>'AdS Image',
    'id'=>'adsimg',
    'before_widget'=>'',
    'after_widget'=>''
]);

register_sidebar([
    'name'=>'AdS Image_2',
    'id'=>'adsimg_2',
    'before_widget'=>'',
    'after_widget'=>''
]);

register_sidebar([
    'name'=>'AdS Image_3',
    'id'=>'adsimg_3',
    'before_widget'=>'',
    'after_widget'=>''
]);


register_sidebar([
    'name'=>'tab Image_1',
    'id'=>'tabimg_1',
    'before_widget'=>'',
    'after_widget'=>''
]);

register_sidebar([
    'name'=>'tab Image_2',
    'id'=>'tabimg_2',
    'before_widget'=>'',
    'after_widget'=>''
]);

register_sidebar([
    'name'=>'tab Image_3',
    'id'=>'tabimg_3',
    'before_widget'=>'',
    'after_widget'=>''
]);

register_sidebar([
    'name'=>'tab Image_4',
    'id'=>'tabimg_4',
    'before_widget'=>'',
    'after_widget'=>''
]);

register_sidebar([
    'name'=>'tab Image_5',
    'id'=>'tabimg_5',
    'before_widget'=>'',
    'after_widget'=>''
]);

?>