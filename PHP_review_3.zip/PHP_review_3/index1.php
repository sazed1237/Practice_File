<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Page Title</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='main.css'>
    <script src='main.js'></script>
</head>
<body>
    <?php
    readfile("demo.txt");
    

    $info_file = "info.txt";
    $info = fopen($info_file, "r") or die("unable to open file!");
    echo fread($info, filesize($info_file));
    fclose($info);


    $info = fopen($info_file, "w") or die("unable to open file!");
    $txt = "this is new line!\n";
    echo fwrite($info, $txt);
    fclose($info);
    ?>
</body>
</html>