<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Page Title</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='main.css'>

    <?php wp_head(); ?>

</head>
<body>
    
<section class="container-fluid slider">
        <?php 
        $qry1 = new WP_Query([
            'post_type'=>'post',
            'category_name'=>'slider'
        ]);
        
        ?>
        <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">

            <div class="carousel-inner">

            <?php
            $x = 0;
            while ($qry1->have_posts()):$qry1->the_post();
            $x++;
            ?>

            <div class="carousel-item <?= ($x==1)? 'active':''?> ">
            <?php the_post_thumbnail(); ?>
            <!-- <img src="..." class="d-block w-100" alt="..."> -->
            </div>
            <?php endwhile; ?>
            </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
        </div>
    </section>

    <!-- slider part end  -->

        <!-- logo part start -->

        <section class="container-fluid logo">
            <div class="row">
                <div class="col-lg-6 logo_left">
                    <?php the_custom_logo(); ?>
                </div>
                <div class="col-lg-6 logo_right text-end">
                    <?php dynamic_sidebar('logoright') ?>
                </div>
            </div>
        </section>

        <!-- logo part end -->

        <!-- navbar paart start -->

        <section class="container-fluid menu">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <div class="collapse navbar-collapse" id="navbarNav">

                <?php

                    wp_nav_menu([
                        'menu_locations' => 'TM',
                        'menu_class' => 'navbar Project_menu '
                    ]);
                    
                    
                    ?>
                <ul class="navbar-nav">
                    
                    <li class="nav-item">
                    <!-- <a class="nav-link active" aria-current="page" href="#">Home</a> -->
                    </li>
                    
                </ul>
                </div>
            </div>
            </nav>
        </section>

        <!-- navbar paart end -->


        <!-- hero part start  -->
        
        <section class="container hero">
            <div class="hero_heading mt-5">
                <?php dynamic_sidebar('h_heading') ?>
            </div>

            <div class="row mt-5">
                <div class="col-lg-4">
                <div class="card" style="width: 18rem;">
                <?php dynamic_sidebar('h_card1') ?>
                    <!-- <img src="..." class="card-img-top" alt="..."> -->
                    </div>
                </div>
                <div class="col-lg-4">
                <div class="card" style="width: 18rem;">
                <?php dynamic_sidebar('h_card2') ?>
                    <!-- <img src="..." class="card-img-top" alt="..."> -->
                    </div>
                </div>
                <div class="col-lg-4">
                <div class="card" style="width: 18rem;">
                <?php dynamic_sidebar('h_card3') ?>
                    <!-- <img src="..." class="card-img-top" alt="..."> -->
                    </div>
                </div>
            </div>
        </section>


        <!-- hero part end -->


        <!-- separator part start -->

        <section class="container separator mt-5">
            <div class="row ">
                <div class="col-lg-4 mt-3">
                    <?php dynamic_sidebar('s_imgleft') ?>
                </div>
                <div class="col-lg-4">
                    <?php dynamic_sidebar('s_txt') ?>
                </div>
                <div class="col-lg-4 mt-3">
                <?php dynamic_sidebar('s_imgright') ?>
                </div>
            </div>
        </section>

        <!-- separator part end -->


        <!-- photo card start -->

        <section class="container hero">
            
            <div class="row mt-5">
                <div class="col-lg-3">
                <div class="card" style="width: 16rem;">
                <?php dynamic_sidebar('p_card1') ?>
                    <!-- <img src="..." class="card-img-top" alt="..."> -->
                    </div>
                </div>
                <div class="col-lg-3">
                <div class="card" style="width: 16rem;">
                <?php dynamic_sidebar('p_card2') ?>
                    <!-- <img src="..." class="card-img-top" alt="..."> -->
                    </div>
                </div>
                <div class="col-lg-3">
                <div class="card" style="width: 16rem;">
                <?php dynamic_sidebar('p_card3') ?>
                    <!-- <img src="..." class="card-img-top" alt="..."> -->
                    </div>
                </div>
                <div class="col-lg-3">
                <div class="card" style="width: 16rem;">
                <?php dynamic_sidebar('p_card4') ?>
                    <!-- <img src="..." class="card-img-top" alt="..."> -->
                    </div>
                </div>
            </div>
        </section>
                    
        <!-- photo card start -->

        
        <!-- separator part start -->

        <section class="container separator mt-5">
            <div class="row ">
                <div class="col-lg-4 mt-3">
                    <?php dynamic_sidebar('s_imgleft') ?>
                </div>
                <div class="col-lg-4">
                    <?php dynamic_sidebar('s_txt2') ?>
                </div>
                <div class="col-lg-4 mt-3">
                <?php dynamic_sidebar('s_imgright') ?>
                </div>
            </div>
        </section>

        <!-- separator part end -->


                <!-- slider part 2 -->

        <section class="container-fluid slider mt-5">
            <div class="container">
        <?php 
        $qry2 = new WP_Query([
            'post_type'=>'post',
            'category_name'=>'news'
        ]);
        
        ?>
        <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">

            <div class="carousel-inner">

            <?php
            $x = 0;
            while ($qry2->have_posts()):$qry2->the_post();
            $x++;
            ?>

            <div class="carousel-item <?= ($x==1)? 'active':''?> ">
            <?php the_title(); ?>
            <!-- <img src="..." class="d-block w-100" alt="..."> -->
            </div>
            <?php endwhile; ?>
            </div>
        </div>
        </div>
    </section>

    <!-- slider part end  -->


    <!-- footer part start -->

        <footer class="container-fluid ">
            <div class="container footer_main ">
                <div class="row ">
                    <div class="col-lg-6 footer_left mt-2">
                        <?php dynamic_sidebar('f_left') ?>
                    </div>
                    <div class="col-lg-6 footer_right mt-2">
                    <?php dynamic_sidebar('f_right') ?>
                    </div>
                </div>
                <div class="athor">
                    <div class="row author_main d-flex">
                        <div class="col-lg-6 author_left">
                            <p>POWERED BY SOLUTION ART LTD</p>
                        </div>
                        <div class="col-lg-6 author_left text-end">
                            <p>COPYRIGHT © 2015. BANGLADESH BRIDGE AUTHORITY.</p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>

    <!-- footer part end -->



    <?php wp_footer(); ?> 
</body>
</html>