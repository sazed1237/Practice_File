<?php 
wp_enqueue_style( 'style-name', get_stylesheet_uri() );
wp_enqueue_style( 'style-bootstrap', get_template_directory_uri() . '/assets/css/bootstrap.min.css' );
wp_enqueue_script( 'script-name', get_template_directory_uri() . '/assets/js/bootstrap.bundle.min.js', array(), '1.0.0', true );


add_theme_support( 'title-tag' );
add_theme_support( 'custom-logo' );
add_theme_support( 'post-thumbnails' );


register_sidebar([
    'name' => 'logo right',
    'id' => 'l_right',
    'before_widget' => '',
    'after_widget' => ''
]);

register_nav_menus([
    'Top_menu' => 'Project menu'
]);

register_sidebar([
    'name' => 'Hero heading',
    'id' => 'h_heading',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'Hero card 1',
    'id' => 'h_card1',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'Hero card 2',
    'id' => 'h_card2',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'Hero card 3',
    'id' => 'h_card3',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'separator img left',
    'id' => 's_img_left',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'separator txt',
    'id' => 's_txt',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'separator txt 2',
    'id' => 's_txt2',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'separator img right',
    'id' => 's_img_right',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'photo card 1',
    'id' => 'p_card1',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'photo card 2',
    'id' => 'p_card2',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'photo card 3',
    'id' => 'p_card3',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'photo card 4',
    'id' => 'p_card4',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'footer Left',
    'id' => 'f_left',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'footer right',
    'id' => 'f_right',
    'before_widget' => '',
    'after_widget' => ''
]);

?>